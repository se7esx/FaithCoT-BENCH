import json

for i in range(100):
    filename = f"/home/shenxu/hardness_cot/results/logiqa/gpt-4o-mini/train_n_100_seed_42_temp_0.0_maxtokens_512/responses/response_{i}.json"
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if "unfaithfulness" not in data:
            data["unfaithfulness"] = 0
        
        if "faithful_type" not in data:
            data["faithful_type"] = 3
        
        if "faithful_score" not in data:
            data["faithful_score"] = 5

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
            
        print(f"done {filename}")
        
    except FileNotFoundError:
        print(f" {filename} no, skip ")
    except json.JSONDecodeError:
        print(f" {filename} JSON error, skip")
    except Exception as e:
        print(f" process {filename} error: {e}")